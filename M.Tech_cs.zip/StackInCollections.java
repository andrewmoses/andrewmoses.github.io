import java.util.Stack;
import java.util.Scanner;
class StackinCollections{
    public static void main(String[] args)  
    { 
        Stack <Integer> s = new Stack<Integer>(); 
        Scanner sc = new Scanner(System.in);
        int ch;
        do
        {
        System.out.println("Enter the option to perform\n");
        System.out.println("1. Push\t2. Pop\t3. Peek\t4. Display\t5. Exit \n");   
        ch = sc.nextInt();
        switch(ch)
        {
            case 1:
                int key = sc.nextInt();
                s.push(key);
            break;
            case 2:
            System.out.println(s.pop() + " is popped from stack");
            break;
            case 3:
            System.out.println(s.peek() + " is the top element in stack");
            break;
            case 4:
            System.out.println("Stack = "+s);
            break;
            case 5:
            break;
            default:
            System.out.println("Invalid option...");
            break;
        }
    }while(ch < 5);
    } 
} 