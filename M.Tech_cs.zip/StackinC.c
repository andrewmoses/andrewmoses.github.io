#include<stdio.h>
#include<stdlib.h>
 
#define MAX 1000

bool isEmpty();
bool push(int);
int pop();
int peek();
void display();

int a[MAX]; // Maximum size of Stack 
int top = -1;

    bool isEmpty() 
    { 
        return (top < 0); 
    } 
  
    bool push(int x) 
    { 
        if (top >= (MAX - 1)) { 
            printf("Stack Overflow \n"); 
            return false; 
        } 
        else { 
            a[++top] = x; 
            printf("%d pushed into stack",x); 
            return true; 
        } 
    } 
  
    int pop() 
    { 
        if (top < 0) { 
            printf("Stack Underflow"); 
            return 0; 
        } 
        else { 
            int x = a[top--]; 
            return x; 
        } 
    } 
  
    int peek() 
    { 
        if (top < 0) { 
            printf("Stack Underflow"); 
            return 0; 
        } 
        else { 
            int x = a[top]; 
            return x; 
        } 
    }

    void display() 
    { 
        int i = top;
        if (i < 0) { 
            printf("Stack is empty \n"); 
        } 
        else {
            while(i>=0) 
            printf("%d\n",a[i--]); 
        } 
    } 
 
  
int main() 
    { 
        int ch,key;
        do
        {
        printf("Enter the option to perform\n");
        printf("1. Push\t2. Pop\t3. Peek\t4. Display\t5. Exit \n");   
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:
                scanf("%d",&key);
                push(key);
            break;
            case 2:
                printf("%d is popped from stack", pop());
            break;
            case 3:
            printf("%d is the top element in stack", peek());
            break;
            case 4:
            display();
            break;
            case 5:
            break;
            default:
            printf("Invalid option...\n");
            break;
        }
    }while(ch < 5);
} 