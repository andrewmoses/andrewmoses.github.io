import java.util.*;

class QueueInJava
{
public static int CAPACITY = 5;
private int[] queue = new int[CAPACITY];
private int size  = 0;
private int rear  = CAPACITY - 1;   // Initally assumed that rear is at end
private int front = 0;

/**
 * Enqueue/Insert an element to the queue. 
 */
int enqueue(int data)
{
    // Queue is full throw Queue out of capacity error.
    if (isFull()) 
    {
        return 0;
    }

    // Ensure rear never crosses array bounds
    rear = (rear + 1) % CAPACITY;

    // Increment queue size
    size++;

    // Enqueue new element to queue
    queue[rear] = data;

    // Successfully enqueued element to queue
    return 1;
}


/**
 * Dequeue/Remove an element from the queue. 
 */
int dequeue()
{
    int data = -1;

    // Queue is empty, throw Queue underflow error
    if (isEmpty())
    {
        return -1;
    }

    // Dequeue element from queue
    data = queue[front];

    // Ensure front never crosses array bounds
    front = (front + 1) % CAPACITY;

    // Decrease queue size
    size--;

    return data;
}


/**
 * Checks if queue is full or not. It returns 1 if queue is full, 
 * overwise returns 0.
 */
boolean isFull()
{
    if (size == CAPACITY)
    return true;
    else return false;
}


/**
 * Checks if queue is empty or not. It returns 1 if queue is empty, 
 * otherwise returns 0.
 */
boolean isEmpty()
{
    if (size == 0)
        return true;
    else return false;
}


/**
 * Gets, front of the queue. If queue is empty return INT_MAX otherwise
 * returns front of queue.
 */
int getFront()
{
    return (isEmpty())
            ? -1
            : queue[front];
}


/**
 * Gets, rear of the queue. If queue is empty return INT_MAX otherwise
 * returns rear of queue.
 */
int getRear()
{
    return (isEmpty())
            ? -1
            : queue[rear];
}


public static void main(String args[])
{
    int ch, data;
    Scanner sc = new Scanner(System.in);
    QueueInJava q = new QueueInJava();
    /* Run indefinitely until user manually terminates */
    do
    {
        /* Queue menu */
        System.out.print("--------------------------------------\n");
        System.out.print("  QUEUE ARRAY IMPLEMENTATION PROGRAM  \n");
        System.out.print("--------------------------------------\n");
        System.out.print("1. Enqueue\n");
        System.out.print("2. Dequeue\n");
        System.out.print("3. Size\n");
        System.out.print("4. Get Rear\n");
        System.out.print("5. Get Front\n");
        System.out.print("6. Exit\n");
        System.out.print("--------------------------------------\n");
        System.out.print("Select an option: ");

//        scanf("%d", &ch);
        ch = sc.nextInt();
        /* Menu control switch */
        switch (ch)
        {
            case 1:
                System.out.print("\nEnter data to enqueue: ");
                data = sc.nextInt();
                // Enqueue function returns 1 on success
                // otherwise 0
                if (q.enqueue(data) == 1)
                    System.out.print("Element added to queue.");
                else
                    System.out.print("Queue is full.");

                break;

            case 2:
                data = q.dequeue();

                // on success dequeue returns element removed
                // otherwise returns -1
                if (data == -1)
                    System.out.print("Queue is empty.");
                else
                    System.out.print("Data => "+ data);

                break;

            case 3: 

                // isEmpty() function returns 1 if queue is emtpy 
                // otherwise returns 0
                if (q.isEmpty())
                    System.out.print("Queue is empty.");
                else 
                    System.out.print("Queue size =>" + q.size);

                break;

            case 4: 

                if (q.isEmpty())
                    System.out.print("Queue is empty.");
                else 
                    System.out.print("Rear => " + q.getRear());

                break;

            case 5: 

                if (q.isEmpty())
                    System.out.print("Queue is empty.");
                else 
                    System.out.print("Front =>" + q.getFront());

                break;

            case 6:
                System.out.print("Exiting from app.\n");
                break;
        
            default:
                System.out.print("Invalid choice, please input number between (0-5).\n");
                break;
        }
    }while (ch<7);

    System.out.print("\n");
}

}