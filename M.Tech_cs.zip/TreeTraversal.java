import java.util.LinkedList;
class Node{
    Node left;
    Node right;
    String data;
    
    Node(String data)
    {
        this.data = data;
    }

    Node(String data, Node left, Node right)
    {
        this.data = data;
        this.left = left;
        this.right = right;
    }
}

class TreeTraversal {
public static void main(String args[])
{
    Node root = createTree();
    System.out.println("BFS traversal :");
    BFS.traversal(root);
    System.out.println();
    System.out.println("DFS traversal :");
    DFS.traversal(root);
}

static Node createTree()
{
Node root = new Node("A",
                new Node("B", new Node ("C"), new Node("D")), new Node("E", new Node ("F"), new Node("G",new Node ("H"),null)));
return root;
}
}

class BFS{
static void traversal(Node n)
{
    LinkedList<Node> tree = new LinkedList<Node>();
    tree.add(n);
    while(!tree.isEmpty())
    {
        n = tree.remove();
        System.out.print(n.data+" ");
        if(n.left!=null)
        tree.add(n.left);
        if(n.right!=null)
        tree.add(n.right);
    }
}
}

class DFS{
static void traversal(Node n)
{
    if ( n == null)
    return;
    System.out.print(n.data + " ");
    traversal(n.left);
    traversal(n.right);
}
}