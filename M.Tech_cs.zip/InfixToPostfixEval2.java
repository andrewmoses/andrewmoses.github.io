//import java.util.Stack; 
import java.util.*;
class CustomStack{
    private ArrayList<Integer> al = new ArrayList<Integer>();
    public Integer pop()
    {
        return al.remove(al.size()-1);
    }
    public void push(int data)
    {
        Integer i = new Integer(data);
        al.add(i);
    }
}
public class InfixToPostfixEval2  
{ 
    // Method to evaluate value of a postfix expression 
    static int evaluatePostfix(String exp) 
    { 
        //create a stack 
        CustomStack stack=new CustomStack(); 
          
        for(int i=0;i<exp.length();i++) 
        { 
            char c=exp.charAt(i); 
              
            if(Character.isDigit(c)) 
            stack.push(c - '0'); 
              
            //  If the scanned character is an operator, pop two 
            // elements from stack apply the operator 
            else
            { 
                int val1 = stack.pop(); 
                int val2 = stack.pop(); 
                  
                switch(c) 
                { 
                    case '+': 
                    stack.push(val2+val1); 
                    break; 
                      
                    case '-': 
                    stack.push(val2- val1); 
                    break; 
                      
                    case '/': 
                    stack.push(val2/val1); 
                    break; 
                      
                    case '*': 
                    stack.push(val2*val1); 
                    break; 
              } 
            } 
        } 
        return stack.pop();     
    } 
      
    public static void main(String[] args)  
    { 
        Scanner sc = new Scanner(System.in);
        String exp = sc.nextLine();
        System.out.println("postfix evaluation: "+evaluatePostfix(exp)); 
    } 
} 